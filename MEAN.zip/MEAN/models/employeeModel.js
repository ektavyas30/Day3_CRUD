const mongoose=require("mongoose");
const constant = require("../constants/regEx");
var employeeSchema=new mongoose.Schema({
    fullName: {
        type: String,
        required: 'This field is required.'
    },
    email: {
        type: String,
        required: 'This field is required.'
    },
    mobile: {
        type: String,
        required: 'This field is required.'
    },
    city: {
        type: String,
        required: 'This field is required.'
    },
});
employeeSchema.path('email').validate((val) => {    
    return constant.Constants.emailRegex.test(val);;
}, 'Invalid Email Id.');

employeeSchema.path('mobile').validate((val) => {
    
    
    return constant.Constants.numberRegex.test(val);;
}, 'Invalid mobile_no.');

mongoose.model('Employee', employeeSchema);